//https://getnada.com/api/v1/inboxes/arel@getnada.com

const fetch = require('node-fetch');
const puppeteer = require('puppeteer');
const cheerio = require('cheerio');
const delay = require('delay');
const chalk = require('chalk');
const fs = require('fs');
const readline = require('readline-sync');

const fakeit = () => new Promise((resolve, reject) => {
    fetch(`https://fake-it.ws/it/`, {
        method: 'GET',
    })
    .then(async res => {
        const json = await res.text()
        $ = cheerio.load(json)
        var months = ['asdasdasd', "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
        const bulan = months.indexOf($('table[class="table table-striped"] tbody tr').eq(3).children('td').eq(1).text().split(' ')[1].toLowerCase());
          
        const result = {
            first_name: $('table[class="table table-striped"] tbody tr').eq(0).children('td').eq(1).text().split(' ')[0],
            last_name: $('table[class="table table-striped"] tbody tr').eq(0).children('td').eq(1).text().split(' ')[1],
            address: $('table[class="table table-striped"] tbody tr').eq(1).children('td').eq(0).text(),
            city: $('table[class="table table-striped"] tbody tr').eq(2).children('td').eq(0).text(),
            post_code: $('table[class="table table-striped"] tbody tr').eq(2).children('td').eq(1).text(),
            iban: $('table[class="table table-striped "] tbody tr').eq(2).children('td').eq(0).text().split(' ')[0],
            date: {
                date: $('table[class="table table-striped"] tbody tr').eq(3).children('td').eq(1).text().split(' ')[0],
                month: bulan.toString(),
                year: $('table[class="table table-striped"] tbody tr').eq(3).children('td').eq(1).text().split(' ')[2]
            },
            email: $('table[class="table table-striped"] tbody tr').eq(4).children('td').eq(1).text()
        }
        resolve(result)
     })
    .catch(err => reject(err))
});


(async () => {
    try {
        //const jumlah = readline.question(' - Jumlah? : ')
        const read_emailnya = fs.readFileSync('email.txt', {encoding: 'utf-8'})
        const emailnya = read_emailnya.includes('\r\n') ? read_emailnya.split('\r\n') : read_emailnya.split('\n')
        const pwnya = readline.question(' - Password? : ')
        for(let i = 0; i<emailnya.length;i++)
        {
            const fake_it_json = await fakeit()
            console.log(fake_it_json)
            const browser = await puppeteer.launch({headless: false, args: [
                "--disable-notifications"
            ]});
            try {
               
                const page = await browser.newPage();
                console.log(chalk.green(`[${i+1}].`))
                console.log(chalk.cyan(`   - Trying registering netflix. @ArelTiyan`))
                await page.goto('https://www.netflix.com/de-en/', {waitUntil: 'networkidle2'});
                await page.waitForSelector('input[type="email"]')
                await page.type('input[type="email"]', emailnya[i])
                await page.click('button[type="submit"]')
                console.log(chalk.cyan(`   - EMAIL : ${emailnya[i]}.`))
                await page.waitForSelector('button[placeholder="registration_button_continue"]', {visible:true})
                await delay(2000)
                await page.click('button[placeholder="registration_button_continue"]')
                await page.waitForSelector('input[data-uia="field-password"]', {visible:true})
                await page.type('input[data-uia="field-password"]', pwnya)
                await delay(2000)
                await page.click('button[placeholder="regForm_button_continue"]')
                await page.waitForSelector('button[placeholder="button_see_plans"]', {visible:true})
                console.log(chalk.cyan(`   - Registering success, procced to pay.`))
                await delay(2000)
                await page.click('button[placeholder="button_see_plans"]')
                await page.waitForSelector('button[placeholder="planSelection_button_continue"]', {visible:true})
                await delay(2000)
                await page.click('button[placeholder="planSelection_button_continue"]')
                await page.waitForSelector('div[data-uia="payment-choice+deDebitOption"]', {visible:true})
                await delay(2000)
                await page.click('div[data-uia="payment-choice+deDebitOption"]')
                await page.waitForSelector('div[class="paymentFormContainer"]', {visible:true})
                console.log(chalk.cyan(`   - IBAN : ${fake_it_json.iban}.`))
                await page.type('input[data-uia="field-firstName"]', fake_it_json.first_name)
                await page.type('input[data-uia="field-lastName"]', fake_it_json.last_name)
                await page.select('select[name="deDebitBirthDate"]', fake_it_json.date.date)
                // await delay(1000)
                // await page.click('option[value="4"]')
                await page.select('select[name="deDebitBirthMonth"]', fake_it_json.date.month)
                await delay(1000)
            //    await page.click('option[label="1"]')
                await page.type('input[data-uia="field-deDebitBirthYear"]', fake_it_json.date.year)
                await page.type('input[data-uia="field-deDebitStreet"]', fake_it_json.address)
                await page.type('input[data-uia="field-deDebitPostalCode"]', fake_it_json.post_code)
                await page.type('input[data-uia="field-deDebitCity"]', fake_it_json.city)
                await page.type('input[data-uia="field-deDebitAccountNumber"]', fake_it_json.iban)
                await delay(2000)
                await page.click('button[id="simplicityPayment-START"]')
                await page.waitForSelector('h1[class="orderFinalTitle"]')
                console.log(chalk.cyan(`   - Pay success!!.`))
                fs.writeFileSync('email.txt', read_emailnya.replace(read_emailnya.includes('\r\n')? emailnya[i]+'\r\n' : emailnya[i]+'\n', ''))
                fs.appendFileSync('res.txt', emailnya[i]+'|'+pwnya+'\n')
                await browser.close() 
                console.log(chalk.cyan(`   - Success saved to res.txt!!.`))
 
            } catch (error) {
                browser.close()
                console.log(error)
            }
        }
        
    } catch (error) {
        console.log(error)
    }
})()

